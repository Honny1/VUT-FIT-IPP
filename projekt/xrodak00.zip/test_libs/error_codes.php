<?php
define("PARAMETR_ERROR", 10);
define("INPUT_FILE_OPEN_ERROR", 11);
define("OUTPUT_FILE_OPEN_ERROR", 12);


define("FILE_OR_PATH_ERROR", 41);

define("INTERNAL_ERROR", 99);

define("EXIT_OK", 0);
?>
