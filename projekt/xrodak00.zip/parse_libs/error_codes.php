<?php
define("PARAMETR_ERROR", 10);
define("INPUT_FILE_OPEN_ERROR", 11);
define("OUTPUT_FILE_OPEN_ERROR", 12);

define("HEADER_ERROR", 21);
define("OPERATION_CODE_ERROR", 22);
define("LEX_SYN_ERROR", 23);

define("INTERNAL_ERROR", 99);

define("EXIT_OK", 0);
?>
